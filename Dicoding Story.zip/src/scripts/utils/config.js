const Config = {
  API_BASE_URL: "https://story-api.dicoding.dev/v1",
  MAX_FILE_SIZE: 1024 * 1024, // 1MB untuk batas ukuran foto
  VAPID_PUBLIC_KEY:
    "BCCs2eonMI-6H2ctvFaWg-UYdDv387Vno_bzUzALpB442r2lCnsHmtrx8biyPi_E-1fSGABK_Qs_GlvPoJJqxbk",
};

export default Config;
